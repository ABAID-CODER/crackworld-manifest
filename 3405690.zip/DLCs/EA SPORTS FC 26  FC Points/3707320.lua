addappid(3707320, 1)

--made by v80qk on discord