addappid(3035570, 1)

--made by v80qk on discord