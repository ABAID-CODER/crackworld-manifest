addappid(1196360, 1)

--made by v80qk on discord