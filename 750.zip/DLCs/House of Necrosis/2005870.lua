addappid(2005870, 1)

--made by v80qk on discord