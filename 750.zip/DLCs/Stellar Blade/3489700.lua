addappid(3489700, 1)

--made by v80qk on discord