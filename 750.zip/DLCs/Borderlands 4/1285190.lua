addappid(1285190, 1)

--made by v80qk on discord