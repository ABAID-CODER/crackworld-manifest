addappid(3970060, 1)

--made by v80qk on discord