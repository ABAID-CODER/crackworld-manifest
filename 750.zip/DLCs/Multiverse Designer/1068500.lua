addappid(1068500, 1)

--made by v80qk on discord