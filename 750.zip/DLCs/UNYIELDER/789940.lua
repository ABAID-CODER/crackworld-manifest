addappid(789940, 1)

--made by v80qk on discord