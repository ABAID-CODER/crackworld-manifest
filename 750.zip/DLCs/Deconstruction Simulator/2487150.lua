addappid(2487150, 1)

--made by v80qk on discord