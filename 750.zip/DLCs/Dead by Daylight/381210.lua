addappid(381210, 1)

--made by v80qk on discord