addappid(1295660, 1)

--made by v80qk on discord