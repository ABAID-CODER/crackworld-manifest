addappid(3843520, 1)

--made by v80qk on discord