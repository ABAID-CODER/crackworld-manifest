addappid(473930, 1)

--made by v80qk on discord