addappid(1659040, 1)

--made by v80qk on discord