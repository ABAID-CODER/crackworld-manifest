addappid(1984270, 1)

--made by v80qk on discord