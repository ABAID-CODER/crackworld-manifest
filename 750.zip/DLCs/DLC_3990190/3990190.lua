addappid(3990190, 1)

--made by v80qk on discord