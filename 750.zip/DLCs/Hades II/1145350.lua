addappid(1145350, 1)

--made by v80qk on discord