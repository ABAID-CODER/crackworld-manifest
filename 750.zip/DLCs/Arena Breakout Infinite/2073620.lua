addappid(2073620, 1)

--made by v80qk on discord