addappid(1364780, 1)

--made by v80qk on discord