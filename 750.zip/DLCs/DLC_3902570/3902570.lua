addappid(3902570, 1)

--made by v80qk on discord