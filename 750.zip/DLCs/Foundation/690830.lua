addappid(690830, 1)

--made by v80qk on discord