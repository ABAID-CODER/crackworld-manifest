addappid(1284190, 1)

--made by v80qk on discord