addappid(3815860, 1)

--made by v80qk on discord