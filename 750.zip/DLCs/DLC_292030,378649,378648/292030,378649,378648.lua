addappid(292030,378649,378648, 1)

--made by v80qk on discord