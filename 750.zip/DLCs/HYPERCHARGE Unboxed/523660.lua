addappid(523660, 1)

--made by v80qk on discord