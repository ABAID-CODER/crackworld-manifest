addappid(3601140, 1)

--made by v80qk on discord