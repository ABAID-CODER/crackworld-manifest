addappid(3354750, 1)

--made by v80qk on discord