addappid(1763470, 1)

--made by v80qk on discord