addappid(1969370, 1)

--made by v80qk on discord