addappid(3215820, 1)

--made by v80qk on discord