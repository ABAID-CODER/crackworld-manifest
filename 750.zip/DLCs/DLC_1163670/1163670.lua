addappid(1163670, 1)

--made by v80qk on discord