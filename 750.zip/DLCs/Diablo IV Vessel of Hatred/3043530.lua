addappid(3043530, 1)

--made by v80qk on discord