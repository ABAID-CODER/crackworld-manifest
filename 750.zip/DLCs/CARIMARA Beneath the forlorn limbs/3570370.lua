addappid(3570370, 1)

--made by v80qk on discord