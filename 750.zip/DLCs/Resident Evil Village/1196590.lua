addappid(1196590, 1)

--made by v80qk on discord