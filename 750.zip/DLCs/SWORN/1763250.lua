addappid(1763250, 1)

--made by v80qk on discord