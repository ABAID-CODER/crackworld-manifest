addappid(3919760, 1)

--made by v80qk on discord