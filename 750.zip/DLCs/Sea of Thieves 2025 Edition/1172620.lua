addappid(1172620, 1)

--made by v80qk on discord