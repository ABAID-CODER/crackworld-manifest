addappid(2947440, 1)

--made by v80qk on discord