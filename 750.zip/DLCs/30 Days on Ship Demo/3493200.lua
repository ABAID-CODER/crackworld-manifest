addappid(3493200, 1)

--made by v80qk on discord