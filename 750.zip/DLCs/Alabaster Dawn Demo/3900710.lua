addappid(3900710, 1)

--made by v80qk on discord