addappid(1551360, 1)

--made by v80qk on discord