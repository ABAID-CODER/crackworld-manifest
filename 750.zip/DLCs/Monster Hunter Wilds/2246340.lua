addappid(2246340, 1)

--made by v80qk on discord