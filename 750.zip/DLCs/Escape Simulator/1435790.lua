addappid(1435790, 1)

--made by v80qk on discord