addappid(2344520,3043530, 1)

--made by v80qk on discord