addappid(3314790, 1)

--made by v80qk on discord