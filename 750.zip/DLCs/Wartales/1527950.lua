addappid(1527950, 1)

--made by v80qk on discord