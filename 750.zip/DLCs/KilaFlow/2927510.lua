addappid(2927510, 1)

--made by v80qk on discord