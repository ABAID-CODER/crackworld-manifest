addappid(2138720, 1)

--made by v80qk on discord