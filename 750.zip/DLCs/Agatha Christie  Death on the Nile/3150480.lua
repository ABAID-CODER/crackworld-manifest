addappid(3150480, 1)

--made by v80qk on discord