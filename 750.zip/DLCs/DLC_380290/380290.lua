addappid(380290, 1)

--made by v80qk on discord