addappid(2385530, 1)

--made by v80qk on discord