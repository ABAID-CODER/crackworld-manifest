addappid(3436030, 1)

--made by v80qk on discord