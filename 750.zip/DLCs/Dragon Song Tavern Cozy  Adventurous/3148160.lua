addappid(3148160, 1)

--made by v80qk on discord