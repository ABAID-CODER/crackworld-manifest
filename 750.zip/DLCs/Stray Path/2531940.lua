addappid(2531940, 1)

--made by v80qk on discord