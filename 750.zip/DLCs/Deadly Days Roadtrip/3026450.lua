addappid(3026450, 1)

--made by v80qk on discord