addappid(1281040, 1)

--made by v80qk on discord