addappid(3577060, 1)

--made by v80qk on discord