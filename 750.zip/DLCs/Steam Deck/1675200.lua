addappid(1675200, 1)

--made by v80qk on discord