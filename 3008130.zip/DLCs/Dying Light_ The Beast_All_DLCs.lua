addappid(3592040, 1)
addappid(3707620, 1)
addappid(3707630, 1)
addappid(3707640, 1)
addappid(3707650, 1)
addappid(3707710, 1)

--made by v80qk on discord