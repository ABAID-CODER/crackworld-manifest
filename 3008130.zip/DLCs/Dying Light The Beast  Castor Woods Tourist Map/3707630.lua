addappid(3707630, 1)

--made by v80qk on discord