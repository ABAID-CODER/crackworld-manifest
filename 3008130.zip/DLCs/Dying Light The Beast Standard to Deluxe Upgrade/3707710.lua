addappid(3707710, 1)

--made by v80qk on discord